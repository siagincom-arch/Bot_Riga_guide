# Riga Guide Bot — Tests
